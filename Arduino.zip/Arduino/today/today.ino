#include <WiFi.h>
#include <DHT.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ================= WIFI =================
const char* ssid = "vivo Y19 5G";
const char* password = "abcdiop123cd";

WiFiServer server(80);

// ================= DHT =================
#define DHTPIN 4
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

// ================= RELAYS =================
#define RELAY1 27
#define RELAY2 26
#define RELAY3 25
#define RELAY4 33

// ================= LEDS =================
#define GREEN_LED 14
#define RED_LED 12

// ================= LCD =================
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {

  // ================= SERIAL =================
  Serial.begin(115200);

  // ================= RELAY SETUP =================
  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);
  pinMode(RELAY3, OUTPUT);
  pinMode(RELAY4, OUTPUT);

  // Relay OFF initially
  digitalWrite(RELAY1, HIGH);
  digitalWrite(RELAY2, HIGH);
  digitalWrite(RELAY3, HIGH);
  digitalWrite(RELAY4, HIGH);

  // ================= LED SETUP =================
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);

  digitalWrite(GREEN_LED, LOW);
  digitalWrite(RED_LED, LOW);

  // ================= DHT START =================
  dht.begin();

  // ================= LCD START =================
  Wire.begin();

  lcd.begin();
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("SMART HOME");

  lcd.setCursor(0, 1);
  lcd.print("Connecting...");

  // ================= WIFI CONNECT =================
  WiFi.begin(ssid, password);

  int wifi_try = 0;

  while (WiFi.status() != WL_CONNECTED && wifi_try < 30) {

    delay(500);
    Serial.print(".");

    wifi_try++;
  }

  // ================= WIFI SUCCESS =================
  if (WiFi.status() == WL_CONNECTED) {

    Serial.println("\nWiFi Connected");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());

    lcd.clear();

    lcd.setCursor(0, 0);
    lcd.print("WiFi Connected");

    lcd.setCursor(0, 1);
    lcd.print(WiFi.localIP());

    delay(3000);

  } else {

    Serial.println("\nWiFi Failed");

    lcd.clear();

    lcd.setCursor(0, 0);
    lcd.print("WiFi Failed");

    while (true);
  }

  // ================= IMPORTANT FIX =================
  WiFi.setSleep(false);

  // ================= START SERVER =================
  server.begin();

  Serial.println("Web Server Started");

  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print("SERVER STARTED");

  delay(2000);
}

void loop() {

  // ================= READ SENSOR =================
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();

  // ================= DHT CHECK =================
  if (isnan(temp) || isnan(hum)) {

    Serial.println("DHT Sensor Error");

    lcd.clear();

    lcd.setCursor(0, 0);
    lcd.print("DHT ERROR");

    delay(2000);

    return;
  }

  // ================= LCD DISPLAY =================
  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print("T:");
  lcd.print(temp, 1);
  lcd.print("C");

  lcd.setCursor(8, 0);
  lcd.print("H:");
  lcd.print((int)hum);
  lcd.print("%");

  // ================= WEATHER =================
// ================= WEATHER =================
lcd.setCursor(0, 1);

if (temp > 31 || hum > 65) {

  digitalWrite(RED_LED, HIGH);
  digitalWrite(GREEN_LED, LOW);

  lcd.print("ANOMALY DETECT");

} else {

  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, HIGH);

  lcd.print("NORMAL CONDITION");
}
  // ================= CLIENT CHECK =================
  WiFiClient client = server.available();

  if (client) {

    Serial.println("New Client Connected");

    unsigned long timeout = millis();

    while (!client.available() && millis() - timeout < 2000) {
      delay(1);
    }

    if (client.available()) {

      String request = client.readStringUntil('\r');

      Serial.println(request);

      client.flush();

      // ================= RELAY ON =================
      if (request.indexOf("/ON") != -1) {

        digitalWrite(RELAY1, LOW);
        digitalWrite(RELAY2, LOW);
        digitalWrite(RELAY3, LOW);
        digitalWrite(RELAY4, LOW);

        Serial.println("Human Detected -> Appliances ON");
      }

      // ================= RELAY OFF =================
      if (request.indexOf("/OFF") != -1) {

        digitalWrite(RELAY1, HIGH);
        digitalWrite(RELAY2, HIGH);
        digitalWrite(RELAY3, HIGH);
        digitalWrite(RELAY4, HIGH);

        Serial.println("No Human -> Appliances OFF");
      }

      // ================= SEND RESPONSE =================
      client.println("HTTP/1.1 200 OK");
      client.println("Content-type:text/html");
      client.println("Connection: close");
      client.println();

      client.println("ESP32 SERVER WORKING");

      delay(5);

      client.stop();

      Serial.println("Client Disconnected");
    }
  }

  // ================= SERIAL MONITOR =================
  Serial.print("Temperature: ");
  Serial.print(temp);

  Serial.print(" C | Humidity: ");
  Serial.print(hum);

  Serial.println(" %");

  delay(2000);
}