import cv2
import requests
import time
from ultralytics import YOLO

# ================= ESP32 IP =================
ESP_IP = "10.28.112.11"

# ================= LOAD YOLO MODEL =================
model = YOLO("yolov8n.pt")

print("AI SMART HOME STARTED")

# ================= CAMERA =================
cap = cv2.VideoCapture(0)

# FAST CAMERA SETTINGS
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

# ================= VARIABLES =================
last_sent = None
last_human_time = time.time()

OFF_DELAY = 5 

# WAIT FOR ESP32 SERVER START
time.sleep(3)

while True:

    ret, frame = cap.read()

    if not ret:
        break

    # ================= RESIZE =================
    frame = cv2.resize(frame, (500, 500))

    # ================= YOLO DETECTION =================
    results = model(
        frame,
        imgsz=320,
        conf=0.60,
        verbose=False
    )

    person_detected = False

    # ================= PERSON CHECK =================
    for r in results:

        for box in r.boxes:

            cls = int(box.cls[0])

            # PERSON CLASS
            if cls == 0:

                person_detected = True

                x1, y1, x2, y2 = map(int, box.xyxy[0])

                # PERSON BOX
                cv2.rectangle(
                    frame,
                    (x1, y1),
                    (x2, y2),
                    (0, 255, 0),
                    2
                )

                cv2.putText(
                    frame,
                    "PERSON",
                    (x1, y1 - 5),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 0),
                    2
                )

                break

    # ================= HUMAN DETECTED =================
    if person_detected:

        last_human_time = time.time()

        # STATUS TEXT
        cv2.putText(
            frame,
            "STATE: HUMAN DETECTED",
            (10, 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (0, 255, 0),
            2
        )

        if last_sent != "ON":

            try:

                response = requests.get(
                    f"http://{ESP_IP}/ON",
                    timeout=2
                )

                if response.status_code == 200:

                    print("Human Detected -> ON")

                    last_sent = "ON"

                else:

                    last_sent = None

                time.sleep(1)

            except:

                print("ESP32 Not Connected")

                last_sent = None

                time.sleep(2)

    # ================= NO HUMAN =================
    else:

        # STATUS TEXT
        cv2.putText(
            frame,
            "STATE: NO HUMAN",
            (10, 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (0, 0, 255),
            2
        )

        if time.time() - last_human_time > OFF_DELAY:

            if last_sent != "OFF":

                try:

                    response = requests.get(
                        f"http://{ESP_IP}/OFF",
                        timeout=2
                    )

                    if response.status_code == 200:

                        print("No Human -> OFF")

                        last_sent = "OFF"

                    else:

                        last_sent = None

                    time.sleep(1)

                except:

                    print("ESP32 Not Connected")

                    last_sent = None

                    time.sleep(2)

    # ================= DISPLAY =================
    display = cv2.resize(frame, (480, 360))

    cv2.imshow("AI SMART HOME", display)

    # ================= EXIT =================
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# ================= CLEANUP =================
cap.release()
cv2.destroyAllWindows()
